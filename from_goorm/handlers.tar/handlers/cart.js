import {Cart} from '../models';
import mongoose from 'mongoose';
import 
{
	cartColName, 
	productColName,
	custColName
} from '../models/CartSchema';
import{colName} from '../models/CookieSchema';

async function addToCart(req, res, next){
	try{
		const user_id = mongoose.Types.ObjectId("5ff35668b60e411de4c1efe6");//get from token and browser cookie.
		const product_id = mongoose.Types.ObjectId(req.body.id);
		let filter = {
			[cartColName.PRODUCTS]:{
				$elemMatch: {
					[productColName.DETAILS]: product_id
				}
			},
			[cartColName.CUSTOMER]:{
				[custColName.DETAILS]: user_id
			}
		}
		let cart = await Cart.findOne(filter)
		console.log('add',cart)
		if(cart){
			return next({
				status: 400,
				message: 'Product is already in cart'
			});
		}
		
		else{
			filter = {
				[cartColName.CUSTOMER]:{
					[custColName.DETAILS]: user_id
				}
			}
			const update = {
				$push:{
					[cartColName.PRODUCTS]:{
						[productColName.DETAILS]: product_id,
						[productColName.QUANTITY]: 1
					}
				},
				[cartColName.CUSTOMER]:{
					[custColName.DETAILS]: user_id
				}
			}
			const options ={
				new: true,
				upsert: true,
				runValidators: true,
				context: 'query'
			}
			cart = await Cart.findOneAndUpdate(filter, update, options);
			res.status(200).json(cart);
		}
	}
	catch(error){
		return next({
			status:400,
			message: error.message
		})
	}
}

async function addOneMore(req, res, next){
	try{
		const product_id = mongoose.Types.ObjectId(req.body.id);
		const user_id = mongoose.Types.ObjectId("5ff35668b60e411de4c1efe6");//get from token and cookie.
		
		let filter = {
			[cartColName.CUSTOMER]:{
				[custColName.DETAILS]: user_id
			}
		}
		const projection = {
			[cartColName.PRODUCTS]:{
				$elemMatch: {
					[productColName.DETAILS]: product_id
				}
			}
		}
		const products = await Cart.findOne(filter, projection)	
		let productQuantityInCart = products[cartColName.PRODUCTS][0][productColName.QUANTITY];
		
		productQuantityInCart++;
		console.log('quant1', products,productQuantityInCart)
		const updatePath = `${cartColName.PRODUCTS}.$.${productColName.QUANTITY}`;
		
		filter = {
			[cartColName.PRODUCTS]:{
				$elemMatch: {
					[productColName.DETAILS]: product_id
				}
			},
			[cartColName.CUSTOMER]:{
				[custColName.DETAILS]: user_id
			}
			
		}
		
		const update ={
			'$set': {
				[updatePath]: productQuantityInCart
			}
		};
		const options = {
			new: true,
			runValidators: true,
			context: 'query'
		};
		// res.send('hi');
		const cart = await Cart.findOneAndUpdate(filter, update, options);
		res.status(200).json(cart);
	}
	catch(error){
		return next({
			status:400,
			message: error.message
		});
	}
}

async function removeOne(req, res, next){
	try{
		const product_id = mongoose.Types.ObjectId(req.body.id);
		const user_id = mongoose.Types.ObjectId("5ff3235bc481fd05e4850a01");//get from token and cookie.
		
		const filter = {
			[cartColName.PRODUCTS]:{
				$elemMatch: {
					[productColName.DETAILS]: product_id
				}
			},
			[cartColName.CUSTOMER]:{
				[custColName.DETAILS]: user_id
			}
		}
		
		const products = await Cart.findOne(filter);
		let productQuantityInCart = products[cartColName.PRODUCTS][0][productColName.QUANTITY];
		let cart = {};
		if(productQuantityInCart > 1){
			productQuantityInCart--;
			const updatePath = `${cartColName.PRODUCTS}.$.${productColName.QUANTITY}`;
			const update = {
				$set:{
					[updatePath]: productQuantityInCart
				}
			};
			const options = {
				new: true
			};
			cart = await Cart.findOneAndUpdate(filter, update, options);
		}
		else if(productQuantityInCart == 1){
			const update = {
				$pull:{
					[cartColName.PRODUCTS]:{
						[productColName.DETAILS]: product_id
					}
				}
			};
			const options = {
				new: true
			};
			cart = await Cart.findOneAndUpdate(filter, update, options);
		}
		res.status(200).json(cart);
	}
	catch(error){
		return next({
			status:400,
			message: error.message
		})
	}
}

async function getCart(req, res, next){
	try{
		const user_id = mongoose.Types.ObjectId("5ff3235bc481fd05e4850a01");//get from token and cookie.
		const filter = {
			[cartColName.CUSTOMER]:{
				[custColName.DETAILS]: user_id
			}
		};
		const cart = await Cart.findOne(filter);
		res.status(200).json(cart);
	}
	catch(error){
		return next({
			status:400,
			message: error.message
		})
	}
}

export {addToCart, addOneMore, removeOne, getCart};