import jwt from 'jsonwebtoken';
require('dotevn').load();


//authenticate
function isLoggedIn(req, res, next){
	try{
		const token = req.authorization.split(' ')[1];
		jwt.verify(token, process.env.SECRET_KEY, (err, decode) => {
			if(decode){
				return next();
			}
			else{
				return next({
					status: 401,
					message: 'Please login first'
				});
			}
		});
	}
	catch(error){
		return next({
			status: 401,
			message: 'Please login first'
		});
	}
}

//authorize
function isCorrectUser(req, res, next){
	try{
		const token = req.authorization.split(' ')[1];
		jwt.verify(token, process.env.SECRET_KEY, (err, decode) => {
			if(decode && decode.id == req.params.id){
				
				return next();
			}
			else{
				return next({
					status: 401,
					message: 'Unauthorized'
				});
			}
		});
	}
	catch(error){
		return next({
			status: 401,
			message: 'Unauthorized'
		});	
	}
}

export {isLoggedIn, isCorrectUser};