import mongoose from 'mongoose';
import bcrypt from 'bcrypt';

const userDocName = 'User';

const colName = {
	EMAIL: 'EMAIL',
	NAME: 'NAME',
	PASSWORD: 'PASSWORD'
}

const schemaObj = {
	[colName.EMAIL]: {
		type: String,
		required: true,
		unique: true
	},
	[colName.PASSWORD]: {
		type: String,
		required: true
	},
	[colName.NAME]: {
		type: String,
		required: true
	}
}

const modelSchema = new mongoose.Schema(schemaObj);

modelSchema.pre('save', async function(next){
	try{
		if(!this.isModified([colName.PASSWORD])){
			return next();
		}
		const saltRounds = 9211420420;
		let hashedPassword = await bcrypt.hash(this[colName.PASSWORD], saltRounds);
		this[colName.PASSWORD] = hashedPassword;
		console.log('hi1',this);
		return next();
	}
	catch(err){
		return next(err);
	}
});

modelSchema.methods.comparePassword = async function(inputPassword, next){
	try{
		const savedPassword = this[colName.PASSWORD];
		let isMatched = await bcrypt.compare(inputPassword, savedPassword)
		return isMatched;
	}
	catch(error){
		return next(error);
	}
}

const User = mongoose.model(userDocName, modelSchema);

export default User;
export {colName, userDocName};