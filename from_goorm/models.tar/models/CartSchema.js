import mongoose from 'mongoose';
import {Cookie} from './index';
import {statusValues, colName, cookieDocName} from './CookieSchema';
import {userDocName} from './UserSchema';

const cartDocName = 'Cart';

const cartColName = {
	PRODUCTS: 'PRODUCTS',
	CUSTOMER: 'CUSTOMER',
	SHIPPING_CHARGE_RS: 'SHIPPING_CHARGE_RS',
	TOTAL_AMOUNT_RS: 'TOTAL_AMOUNT'
};

const productColName = {
	QUANTITY: 'QUANTITY',
	DETAILS: 'DETAILS'
};

const custColName = {
	DETAILS: 'DETAILS'
};

const productSchemaObj = {
	[productColName.QUANTITY]:{
		type: Number,
		required: true,
		default: 1
		// ,
		// validate: {
		// 	validator: isValidQuantity,
		// 	message: 'Product id finished'
		// }
	},
	[productColName.DETAILS]:{
		type: mongoose.Schema.Types.ObjectId,
		ref: cookieDocName,
		required: true
	}
};

const productSchema = new mongoose.Schema(productSchemaObj);

const custSchemaObj = {
	[custColName.DETAILS]:{
		type: mongoose.Schema.Types.ObjectId,
		ref: userDocName,
		required: true,
		unique: true
	}
};

async function isAvailable(reqObj){
	try{
		const requiredQuantity = reqObj[0][productColName.QUANTITY] ? reqObj[0][productColName.QUANTITY] : 1;
		const requiredProductId = reqObj[0][productColName.DETAILS];
		
		const product = await Cookie.findOne({
			_id: requiredProductId
		});
		const productStatus = product[colName.STATUS];
		const productInStockQuantity = product[colName.QUANTITY_IN_STOCK];
		if(productStatus === statusValues[0] && requiredQuantity <= productInStockQuantity){
			return true;
		}
		else{
			return false;
		}
	}
	catch(error){
		return {
			message: error.message
		};
	}
}

async function isValidQuantity(reqObj){
	try{
		const requiredQuantity = reqObj;
		const requiredProductId = this._conditions[cartColName.PRODUCTS].$elemMatch[productColName.DETAILS]
		const product = await Cookie.findOne({
			_id: requiredProductId
		});
		const productStatus = product[colName.STATUS];
		const productInStockQuantity = product[colName.QUANTITY_IN_STOCK];
		if(productStatus === statusValues[0] && requiredQuantity <= productInStockQuantity){
			return true;
		}
		else{
			return false;
		}
	}
	catch(error){
		return {
			message: error.message
		};
	}
}

const schemaObj = {
	[cartColName.PRODUCTS]: {
		type: [productSchema]
		// ,
		// validate: {
		// 	validator: isAvailable,
		// 	message: 'Product is finished'
		// }
	},
	[cartColName.CUSTOMER]:{ 
		type: custSchemaObj,
	},
	[cartColName.SHIPPING_CHARGE_RS]:{
		type: Number,
		required: true,
		default: 50
	},
	[cartColName.TOTAL_AMOUNT_RS]:{
		type: Number,
		required: true,
		default: 0
	}
}

//add total rs before save
//for future discounts and coupons

const modelSchema = new mongoose.Schema(schemaObj);

modelSchema.pre('findOneAndUpdate',async function(next){
	try{
		//check the availability before adding an item to cart and update the total amount of cart
		const docToUpdate = await this.model.findOne(this.getQuery());
		console.log('prehook',this, docToUpdate);
		let totalAmount = 0;
		let requiredProductId = '';
		let requiredQuantity = 0;
		if(docToUpdate){
			totalAmount = docToUpdate[cartColName.TOTAL_AMOUNT_RS];
		}
		if(!this._update.$push){
			requiredProductId = this._conditions[cartColName.PRODUCTS].$elemMatch[productColName.DETAILS];
			const updatePath = `${cartColName.PRODUCTS}.$.${productColName.QUANTITY}`;
			requiredQuantity = this._update.$set[updatePath];
		}
		else{
			requiredProductId = this._update.$push[cartColName.PRODUCTS][productColName.DETAILS];
			requiredQuantity = this._update.$push[cartColName.PRODUCTS][productColName.QUANTITY];
		}
		const product = await Cookie.findOne({
			_id: requiredProductId
		});
		
		//validate the availability
		const productStatus = product[colName.STATUS];
		const productInStockQuantity = product[colName.QUANTITY_IN_STOCK];
		console.log('quant',requiredQuantity, productInStockQuantity);
		if(productStatus === statusValues[0] && requiredQuantity <= productInStockQuantity){
			//if available update the total amount
			const productPriceRs = product[colName.PRICE_RS];
			totalAmount += productPriceRs;
			this.set({[cartColName.TOTAL_AMOUNT_RS]: totalAmount});
		}
		else{
			//if not available throw an error
			const err = docToUpdate.invalidate([productColName.QUANTITY], 'Product if finished', requiredQuantity);
			next(err);
		}
	}
	catch(error){
		return next(error);
	}
});

const Cart = mongoose.model(cartDocName, modelSchema);

export default Cart;
export {cartColName, productColName, custColName, cartDocName};

