import express from 'express';
import {
	addCookie,
	getCookies,
	editCookie,
	deleteCookie
} from '../handlers/cookie'

const router = new express.Router();

router.post('/add', addCookie);
router.get('/getAll', getCookies);
router.post('/edit', editCookie);
router.delete('/delete', deleteCookie);

export default router;