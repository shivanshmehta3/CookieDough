import express from 'express';
import {
	addToCart,
	addOneMore,
	removeOne,
	getCart
} from '../handlers/cart';

const router = new express.Router();

router.post('/add', addToCart);
router.post('/addMore', addOneMore);
router.post('/removeOne', removeOne);
router.get('/get', getCart);

export default router;